+++
author = "Dmitri Senchuk"
title = "week 1. Project management"
date = 2024-01-25
description = "Sample article showcasing formatting for HTML elements."
tags = [
    "markdown",
    "css",
    "html",
    "themes",
]
categories = [
    "themes",
    "syntax",
]
+++
> At the beginning of my studies at FabAcademy, I was full of enthusiasm and curiosity. The first days were stressful but exciting at the same time. 
  The lectures were full of interesting topics. We learned about various 
technologies, from Git to website development. The presentations by the professors were very impressive, especially those where they shared their experiences and successes.  Together with our fellow students, we felt a strong community spirit at the first lectures.
  Getting to know my team was an interesting challenge. We discussed
ideas, shared experiences, and planned joint steps. I felt that we could achieve great results together.
<!--more-->

## Community of web developers: My experience with Git.

This week I installed the necessary software for the course  such as Git, Go, Node.js, Markdown, Hugo, Microsoft Visual Code and additionally installed Install a C compiler, either GCC. 

  I also created my website with Hugo and hosted it on GitHub Pages. I
added my resume, photo, and contact information to my website + my Fab Academy work. 

  I learned how to use Git  to manage versions of my code, to work more
in the terminal, which I didn't like the idea of at first, but eventually I grew to like it, and how to synchronize it with GitHub. I also learned how to use Markdown to create content for my site and how to use Hugo to generate static HTML files. In achieving the goal, I encountered various difficulties, sometimes obvious, as funny as it sounds, because I was thinking and looking for a completely different reason. 

  There were also problems where I sat for more than one hour to figure
it out, turned to the Git documentation for help, this tutorial, and other members of my team, consulted with Konstantin about the structure of the site, what was possible and what was not. 

## From Git to GitHub Pages: My story.
Documentation: [GitLab](https://docs.gitlab.com/ee/tutorials/make_first_git_commit/), [GitBook](https://git-scm.com/book/en/v2), [Hugo Install](https://gohugo.io/installation/windows/).

Video turorial: [YouTube](https://www.youtube.com/watch?v=Ce5nz5n41z4&ab_channel=GitLab) and [Youtube](https://www.youtube.com/watch?v=8JJ101D3knE&ab_channel=ProgrammingwithMosh)

Step 1: Settings git
I followed [the textbook] Git (http://fabacademy.org/2019/docs/FabAcademy-Tutorials/week01_principles_practices_project_management/git_simple.html). 

First, download git with:

brew install git

Set the user configuration for git:

{{< highlight html >}}
$ git config --global user.name "dmitri-senchuk"
$ git config --global user.email "5769650@stud.nau.edu.ua"
{{< /highlight >}}

Check if the SSH key exists:
cat ~/.ssh/id_rsa.pub

If you do not generate an SSH key:

ssh-keygen -t rsa -C "5769650@stud.nau.edu.ua"


Check the public key you just created:
cat ~/.ssh/id_rsa.pub


Step 2. 
Hugo install:
https://github.com/gohugoio/hugo/releases/tag/v0.122.0

![Install Hugo](FabLab/senhuk/images/2step2.jpg)

Via WinGet:
 https://apps.microsoft.com/detail/9N0DX20HK701?rtc=1&hl=uk-ua&gl=UA
 
install hugo on the command line, then write hugo.version on the command line to make sure it is installed and what version it is
The extended version of the hugo code
https://go.dev/doc/install


Install the GCC compiler:
in the Git Bash terminal
git clone git://gcc.gnu.org/git/gcc.git SomeLocalDir
Update the environment variable as described in the GoPATH documentation
Use the GCC documentation 
https://gcc.gnu.org/git.html

![Install GCC](FabLab/senhuk/images/1step2.jpg)

https://gohugo.io/installation/windows/

I used this website template:
https://themes.gohugo.io/themes/aafu/


## Problem with the site(

I want to create a new page, but I get the following error:
{{< highlight html >}}
$ hugo new content posts/fabacademy.md 
  Error: failed to load modules: module "aafu" not found in
"C:\\Users\\Dmitri\\fablab\\aafu\\themes\\aafu";
  either add it as a Hugo Module or store it in
"C:\\Users\\Dmitri\\fablab\\aafu\\themes".
{{< /highlight >}}

Now everything is finally perfect)

We generated our logo using Favicon Generator - Text to Favicon - favicon.io, but there were some difficulties when importing it into the project.

The favicon is not working.

Make sure that you have specified the correct type of file with the icon image in the head.html file located in the layouts/partials folder of your Hugo project. You must use the type attribute with the appropriate value, for example, type="image/x-icon" for .ico files, type="image/png" for .png files, type="image/svg+xml" for .svg files, etc. You can find more information about file types here. 

Make sure you are using a compatible browser to view your website. Not all browsers support all image file formats for icons. For example, Internet Explorer doesn't support .png and .svg files for icons, so you must use an .ico file for it. You can check browser compatibility for different image file formats on this page.

It turns out that the necessary data had to be changed in the project folder in a file called config.yaml
The problem of creating a new tab did not yield any progress, so the next day we had a meeting with the team at the Island, FabLab. After talking to one of the team members, Iryna, she helped me change my approach to the problem and look for it elsewhere. 
Having understood the code and logic of the project, we came to the conclusion that in order to create a new page and tab, we need to add it on the front page, here is the path layouts/partials/header.html 
And add a line:
{{< highlight html >}}
<a class="no-underline p-2 rounded hover:bg-gray-200 dark:hover:bg-gray-800" 
href="{{ `fabacademy` | relURL }}">FabAcademy</a>
{{< /highlight >}}

![hugo server](static/images/3step2.jpg)


<link rel="apple-touch-icon" href="3step2.jpg">
